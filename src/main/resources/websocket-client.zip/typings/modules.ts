declare module 'component-emitter'
