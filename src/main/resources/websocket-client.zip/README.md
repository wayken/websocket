# 项目

基本WebSocket自定义二进制协议通讯客户端

# 参考链接

- [使用前端js爬取斗鱼弹幕](https://blog.csdn.net/qq_39189034/article/details/105844316)
- [通过websocket抓取斗鱼弹幕和礼物消息](http://www.taodudu.cc/news/show-6067759.html?action=onClick)
- [图标](https://www.svgrepo.com/collection/mini-flat-flag-vectors/)
