/**
 * 深度拷贝JSON对象
 *
 * @param {Object} source 要拷贝的对象
 */
export function useDeepClone(source: any) {
  if (null == source) {
    return source
  }
  let newObject: any
  let isArray = false
  if ((source as any).length) {
    newObject = []
    isArray = true
  } else {
    newObject = {}
    isArray = false
  }
  for (const key of Object.keys(source)) {
    if (null == source[key]) {
      if (isArray) {
        newObject.push(null)
      } else {
        newObject[key] = null
      }
    } else {
      const sub = (typeof source[key] == 'object') ? useDeepClone(source[key]) : source[key]
      if (isArray) {
        newObject.push(sub)
      }
      else {
        newObject[key] = sub
      }
    }
  }
  return newObject
}

/**
 * 生成唯一ID
 */
export function uuid() {
  const compose = []
  const hexDigits = '0123456789abcdef'
  for (let i = 0; i < 36; i++) {
    const index = Math.floor(Math.random() * 0x10)
    compose[i] = hexDigits.substring(index, index + 1)
  }
  compose[14] = '4'
  compose[8] = compose[13] = compose[18] = compose[23] = '-'
  return compose.join('')
}

/**
 * 生成导入文件对话框
 */
export function useFileDialog(options: {
  accept?: string,
  multiple?: boolean
}): Promise<FileList | null> {
  return new Promise((resolve) => {
    const inputDom = document.createElement('input')
    inputDom.type = 'file'
    inputDom.onchange = (event: Event) => {
      const result = event.target as HTMLInputElement
      resolve(result.files)
    }
    inputDom.accept = options.accept || '*'
    inputDom.multiple = options.multiple ?? false
    inputDom.click()
  })
}

/**
 * 读取图片文件的dataURL
 */
export const useImageDataURLRead = (file: File): Promise<string> => {
  return new Promise(resolve => {
    const reader = new FileReader()
    reader.addEventListener('load', () => {
      resolve(reader.result as string)
    })
    reader.readAsDataURL(file)
  })
}

/**
 * 文件弹窗下载
 *
 * @param url 文件地址
 * @param filename 保存的文件名
 */
export const useFileDownload = (url: string, filename?: string) => {
  const link = document.createElement('a')
  link.href = url
  if (!filename) {
    filename = new Date().toISOString().replace(/[-:]/g, '').replace('T', '_').split('.')[0]
  }
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
}
