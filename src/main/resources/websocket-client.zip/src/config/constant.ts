/**
 * 全局存储变量名称
 */
const LOCAL_LANG = 'Local-Lang'
const LOCAL_APPERANCE = 'Local-Appearance'
const LOCAL_THEME = 'Local-Theme'
const LOCAL_SOCKET_URL = 'Local-Socket-Url'
const LOCAL_EMIT_COMMAND_NAME = 'Local-Emit-Command-Name'
const LOCAL_EMIT_COMMAND_DATA = 'Local-Emit-Command-Data'
const LOCAL_LISTEN_COMMAND_NAME = 'Local-Listen-Command-Name'

export default {
  LOCAL_LANG,
  LOCAL_APPERANCE,
  LOCAL_THEME,
  DEVICE: {
    DESKTOP: 'desktop',
    TABLET: 'tablet',
    MOBILE: 'mobile'
  },
  LOCAL_SOCKET_URL,
  LOCAL_EMIT_COMMAND_NAME,
  LOCAL_EMIT_COMMAND_DATA,
  LOCAL_LISTEN_COMMAND_NAME
}
