<template>
  <div class="a-home">
    <div class="title">
      <div class="name">{{ $t('portal.title') }}</div>
      <div class="locale inline-flex-r-c-n" @click="handleLangSwitch">
        <a-svg-icon icon-class="locale-language" size="28px" />
        <div class="description">{{ loadCurrentLocalLang.description }}</div>
      </div>
    </div>
    <el-row class="content" :gutter="10">
      <el-col :md="12" :lg="12" :xl="12">
        <div class="card">
          <!-- 服务地址连接 -->
          <div class="name">{{ $t('home.socket-url') }}</div>
          <div class="field address inline-flex-r-c-n">
            <el-input ref="remoteSocketUrlRef" v-model="loadRemoteSocketUrl" autofocus clearable
              :disabled="isSocketConnected || isSocketConnecting"
              :placeholder="$t('home.socket-url-placeholder')"
            ></el-input>
            <el-button v-if="!isSocketConnected" type="primary" @click="handleConnect"
              :loading="isSocketConnecting"
            >
              {{ $t('home.connect') }}
            </el-button>
            <el-button v-else type="warning" @click="handleDisconnect">
              {{ $t('home.disconnect') }}
            </el-button>
          </div>
          <!-- 监听指令 -->
          <div class="name">{{ $t('home.listen-commandname') }}</div>
          <div class="field command">
            <el-input ref="commandListenRef" v-model="loadListenCommandName" clearable
              :disabled="isCommandListenOn"
              :placeholder="$t('home.command-name-placeholder')"
            ></el-input>
            <el-button v-if="!isCommandListenOn" :icon="View" type="success" @click="handleCommandListenOn">
              {{ $t('home.listen-on') }}
            </el-button>
            <el-button v-else :icon="Hide" type="info" @click="handleCommandListenOff">
              {{ $t('home.listen-off') }}
            </el-button>
          </div>
          <!-- 发送指令 -->
          <div class="name">{{ $t('home.emit-commandname') }}</div>
          <div class="field">
            <el-input ref="commandNameRef" v-model="loadCommandName" clearable
              :placeholder="$t('home.command-name-emit-placeholder')"
            ></el-input>
          </div>
          <div class="name">{{ $t('home.emit-data') }}</div>
          <div class="field command">
            <el-input ref="commandDataRef" type="textarea" :rows="6" v-model="loadCommandData" clearable></el-input>
            <el-button :icon="Promotion" type="primary" @click="handleCommandEmit">
              {{ $t('home.send') }}
            </el-button>
          </div>
          <div class="field commands inline-flex-r-c-b">
            <el-button type="success" :icon="Paperclip" @click="handleSendAttachment">
              {{ $t('home.send-attachment') }}
            </el-button>
            <el-button type="info" :icon="Connection" @click="handleWebSocketRpcRequest">
              {{ $t('home.ws-rpc') }}
            </el-button>
            <el-button type="warning" :icon="Download" @click="handleDownloadAttachment">
              {{ $t('home.download-attachment') }}
            </el-button>
          </div>
        </div>
      </el-col>
      <el-col :md="12" :lg="12" :xl="12">
        <div class="card" style="max-height: calc(100vh - 68px);">
          <div class="head inline-flex-r-c-b">
            <div class="name">{{ $t('home.message-console') }}</div>
            <div class="operation">
              <el-button type="primary" :icon="Close" link @click="handleConsoleClear">
                {{ $t('home.clear-message') }}
              </el-button>
            </div>
          </div>
          <div class="message" ref="messageConsoleRef">
            <div v-for="(data, index) in loadMessageConsole" :key="index"
              :class="{
                'is-success': data.type === 'success',
                'is-failure': data.type === 'failure'
              }"
            >
              <span class="time">{{ datetimeftfn(data.time) }}</span>
              <span class="divider">=></span>
              <span class="console">{{ data.message }}</span>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import {
  View,
  Hide,
  Close,
  Promotion,
  Connection,
  Paperclip,
  Download
} from '@element-plus/icons-vue'
import Constant from '@/config/constant'
import { ElMessage } from 'element-plus'
import { io, Socket } from '@/websocket/index'
import { useI18n } from 'vue-i18n'
import { setLocalLang } from '@/utils/locale'
import langList from '@/locale/lang.json'
import { datetimeftfn } from '@/hooks/useDataFormatter'
import { useFileDialog, useFileDownload } from '@/utils/dom'

const loadRemoteSocketUrl = ref('http://127.0.0.1:7012/socket.io')
const loadCommandName = ref('')
const loadCommandData = ref('')
const loadListenCommandName = ref('*')
const loadMessageConsole = ref<any[]>([])

const i18n = useI18n()

const remoteSocketUrlRef = ref()
const commandNameRef = ref()
const commandDataRef = ref()
const commandListenRef = ref()
const messageConsoleRef = ref<HTMLDivElement | null>(null)

// Socket 实例
const socket = ref<Socket>()
// Socket 是否已经建立连接
const isSocketConnected = ref(false)
// Socket 是否正在建立连接
const isSocketConnecting = ref(false)
// 是否已经监听指令
const isCommandListenOn = ref(false)
// Socket 连接错误次数
const loadConnectErrorTimes = ref(0)
// Socket 连接最大错误次数
const loadMaxReconnectTimes = 5

const loadCurrentLocalLang = computed(() => {
  for (const data of langList) {
    if (data.key === i18n.locale.value) {
      return data
    }
  }
  return langList[0]
})

onMounted(() => {
  // 从 LocalStorage 获取上次的 Socket 连接信息
  const localSocketUrl = localStorage.getItem(Constant.LOCAL_SOCKET_URL)
  if (localSocketUrl) {
    loadRemoteSocketUrl.value = localSocketUrl
  }
  // 从 LocalStorage 获取上次的发送指令信息
  const localCommandName = localStorage.getItem(Constant.LOCAL_EMIT_COMMAND_NAME)
  const localCommandData = localStorage.getItem(Constant.LOCAL_EMIT_COMMAND_DATA)
  const localListenCommandName = localStorage.getItem(Constant.LOCAL_LISTEN_COMMAND_NAME)
  if (localCommandName) {
    loadCommandName.value = localCommandName
  }
  if (localCommandData) {
    loadCommandData.value = localCommandData
  }
  if (localListenCommandName) {
    loadListenCommandName.value = localListenCommandName
  }
})

const handleLangSwitch = () => {
  const index = langList.findIndex((data) => data.key === i18n.locale.value)
  const nextIndex = index + 1 >= langList.length ? 0 : index + 1
  const nextLang = langList[nextIndex]
  i18n.locale.value = nextLang.key
  setLocalLang(nextLang.key)
}

const handleConnect = () => {
  // 判断输入框是否为空
  if (!loadRemoteSocketUrl.value) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.socket-url-required')
    })
    remoteSocketUrlRef.value.focus()
    return
  }
  // 将 Socket 连接信息存入 LocalStorage
  const url = loadRemoteSocketUrl.value
  localStorage.setItem(Constant.LOCAL_SOCKET_URL, url)
  // 建立连接
  isSocketConnecting.value = true
  socket.value = io(url, {
  })
  // 建立监听
  handleSocketListen(socket.value)
}
const handleSocketListen = (socket: Socket) => {
  // 监听连接成功指令
  socket.on('connect', function() {
    const message = {
      type: 'success',
      time: new Date(),
      message: i18n.t('home.message.socket-connect-success')
    }
    isSocketConnected.value = true
    isSocketConnecting.value = false
    loadConnectErrorTimes.value = 0
    handleMessageConsolePush(message)
  })
  // 监听连接握手指令
  socket.on('handshake', function(data: any) {
    const message = {
      type: 'success',
      time: new Date(),
      message: i18n.t('home.message.socket-handshake') + JSON.stringify(data)
    }
    handleMessageConsolePush(message)
  })
  // 监听连接断开指令
  socket.on('disconnect', function() {
    isSocketConnected.value = false
    const message = {
      type: 'failure',
      time: new Date(),
      message: i18n.t('home.message.socket-disconnect')
    }
    isSocketConnecting.value = false
    isCommandListenOn.value = false
    handleMessageConsolePush(message)
  })
  // 监听连接失败指令
  socket.on('error', function(error) {
    const message = {
      type: 'failure',
      time: new Date(),
      message: i18n.t('home.message.socket-error') + ' ' + error.type
    }
    loadConnectErrorTimes.value++
    if (loadConnectErrorTimes.value >= loadMaxReconnectTimes) {
      isSocketConnecting.value = false
      loadConnectErrorTimes.value = 0
      socket?.disconnect()
    }
    handleMessageConsolePush(message)
  })
}
const handleDisconnect = () => {
  if (isSocketConnected.value) {
    socket.value?.disconnect()
  }
}
// 发送指令消息
const handleCommandEmit = () => {
  // 判断是否成功建立连接
  if (!isSocketConnected.value) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.socket-not-connected')
    })
    return
  }
  // 判断输入框是否为空，截取前后空格
  const commandName = loadCommandName.value.trim()
  // 判断commandName是否为数字，且必须小于65535
  if (!commandName) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.command-name-required')
    })
    commandNameRef.value.focus()
    return
  }
  let commandData: any = loadCommandData.value.trim()
  if (!commandData) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.command-data-required')
    })
    commandDataRef.value.focus()
    return
  }
  // 发送指令
  try {
    commandData = JSON.parse(commandData)
  } catch (error) {
    if (!isNaN(Number(commandData))) {
      commandData = Number(commandData)
    } else if (commandData === 'true') {
      commandData = true
    } else if (commandData === 'false') {
      commandData = false
    }
  }
  socket.value?.emit(commandName, commandData)
  const message = {
    type: 'success',
    time: new Date(),
    message: i18n.t('home.message.command-emit-complete', { placeholder: commandName }) + ' ' + JSON.stringify(commandData)
  }
  handleMessageConsolePush(message)
  // 将发送指令信息存入 LocalStorage
  localStorage.setItem(Constant.LOCAL_EMIT_COMMAND_NAME, commandName.toString())
  localStorage.setItem(Constant.LOCAL_EMIT_COMMAND_DATA, JSON.stringify(commandData))
}
// 监听指令
const handleCommandListenOn = () => {
  // 判断是否成功建立连接
  if (!isSocketConnected.value) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.socket-not-connected')
    })
    return
  }
  // 判断输入框是否为空，截取前后空格
  const commandName = loadListenCommandName.value.trim()
  // 如果指令值为 * 则监听所有指令，否则监听指定指令，且必须小于65535
  if (commandName !== '*' && !commandName) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.command-name-range')
    })
    commandListenRef.value.focus()
    return
  }
  isCommandListenOn.value = true
  // 如果指令值为 * 则监听所有指令，否则监听指定指令
  if (commandName === '*') {
    socket.value?.onAny(function(commandName, ...args) {
      const message = {
        type: 'success',
        time: new Date(),
        message: i18n.t('home.message.command-listen', { placeholder: commandName }) + ' ' + JSON.stringify(args.length === 1 ? args[0] : args)
      }
      handleMessageConsolePush(message)
    })
    const message = {
      type: 'success',
      time: new Date(),
      message: i18n.t('home.message.command-listen-success', { placeholder: commandName })
    }
    handleMessageConsolePush(message)
  } else {
    socket.value?.on(commandName, function(data) {
      const message = {
        type: 'success',
        time: new Date(),
        message: i18n.t('home.message.command-listen', { placeholder: commandName }) + ' ' + JSON.stringify(data)
      }
      handleMessageConsolePush(message)
    })
    const message = {
      type: 'success',
      time: new Date(),
      message: i18n.t('home.message.command-listen-success', { placeholder: commandName })
    }
    handleMessageConsolePush(message)
  }
  // 将监听指令信息存入 LocalStorage
  localStorage.setItem(Constant.LOCAL_LISTEN_COMMAND_NAME, commandName)
}
// 取消监听指令
const handleCommandListenOff = () => {
  // 判断输入框是否为空，截取前后空格
  const commandName = loadListenCommandName.value.trim()
  // 如果指令值为 * 则监听所有指令，否则监听指定指令，且必须小于65535
  if (commandName !== '*' && !commandName) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.command-name-range')
    })
    commandListenRef.value.focus()
    return
  }
  isCommandListenOn.value = false
  // 取消监听指令
  if (commandName === '*') {
    socket.value?.offAny()
  } else {
    socket.value?.off(commandName)
  }
  const message = {
    type: 'success',
    time: new Date(),
    message: i18n.t('home.message.command-listen-off', { placeholder: commandName })
  }
  handleMessageConsolePush(message)
}
const handleConsoleClear = () => {
  loadMessageConsole.value = []
}
// WS RPC 请求响应通讯
const handleWebSocketRpcRequest = () => {
  if (!isSocketConnected.value) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.socket-not-connected')
    })
    return
  }
  socket.value?.request('wsrpc', { username: 'websocket' }).then((res) => {
    const message = {
      type: 'success',
      time: new Date(),
      message: i18n.t('home.websocket-rpc-response') + ' ' + JSON.stringify(res)
    }
    handleMessageConsolePush(message)
  }).catch((err) => {
    const message = {
      type: 'failure',
      time: new Date(),
      message: i18n.t('home.websocket-rpc-error') + ' ' + JSON.stringify(err)
    }
    handleMessageConsolePush(message)
  })
}
// 附件发送通讯
const handleSendAttachment = async () => {
  if (!isSocketConnected.value) {
    ElMessage({ type: 'error', message: i18n.t('home.socket-not-connected') })
    return
  }
  const files = await useFileDialog({ accept: '*', multiple: true })
  if (!files || files.length === 0) {
    ElMessage({ type: 'info', message: i18n.t('home.message.attachment-send-cancel') })
    return
  }
  const fileList = await Promise.all(
    Array.from(files).map(async (file) => {
      const buffer = await file.arrayBuffer()
      return { name: file.name, size: buffer.byteLength, content: buffer }
    })
  )
  socket.value?.emit('attachment', ...fileList)
  const names = fileList.map((f) => f.name).join(', ')
  const message = {
    type: 'success',
    time: new Date(),
    message: i18n.t('home.message.attachment-send-success', { placeholder: names, size: fileList.reduce((s, f) => s + f.size, 0) })
  }
  handleMessageConsolePush(message)
}
const handleDownloadAttachment = () => {
  if (!isSocketConnected.value) {
    ElMessage({
      type: 'error',
      message: i18n.t('home.socket-not-connected')
    })
    return
  }
  socket.value?.request<any[]>('download').then((res) => {
    const files = Array.isArray(res[0]) ? res[0] : res
    for (const file of files) {
      const blob = new Blob([file.content])
      const url = URL.createObjectURL(blob)
      useFileDownload(url, file.name)
      URL.revokeObjectURL(url)
    }
    const message = {
      type: 'success',
      time: new Date(),
      message: i18n.t('home.message.attachment-download-success', { count: files.length })
    }
    handleMessageConsolePush(message)
  }).catch((err) => {
    const message = {
      type: 'failure',
      time: new Date(),
      message: i18n.t('home.message.attachment-download-error') + ' ' + JSON.stringify(err)
    }
    handleMessageConsolePush(message)
  })
}
const handleMessageConsolePush = (message: any) => {
  loadMessageConsole.value.push(message)
  nextTick(() => {
    if (messageConsoleRef.value) {
      messageConsoleRef.value.scrollTop = messageConsoleRef.value.scrollHeight
    }
  })
}
</script>
